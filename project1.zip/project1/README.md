# Project 1 & 16-bit ALU

## Build
Make sure you have a C++17 compiler (g++ recommended).

To build CLI:
